package atividade2;

/**
 *
 * @author mariana
 */
public interface Widgets {
    
    public void render();
}
