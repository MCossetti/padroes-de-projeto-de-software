package atividade2;

/**
 *
 * @author mariana
 */
public class TextArea implements Widgets {
    
    @Override
    public void render() {
        System.out.println("Renderizando uma caixa de texto...");
    }
}