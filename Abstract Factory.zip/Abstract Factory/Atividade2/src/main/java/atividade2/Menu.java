package atividade2;

/**
 *
 * @author mariana
 */
public class Menu implements Widgets {
    
    @Override
    public void render() {
        System.out.println("Renderizando um menu...");
    }
}