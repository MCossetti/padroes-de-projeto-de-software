package atividade2;

/**
 *
 * @author mariana
 */
public class Button implements Widgets {
    
    @Override
    public void render() {
        System.out.println("Renderizando um botão...");
    }
}
