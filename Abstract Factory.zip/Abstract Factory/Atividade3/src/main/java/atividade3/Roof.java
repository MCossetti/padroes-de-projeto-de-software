package atividade3;

/**
 *
 * @author mariana
 */
public class Roof implements House {

    @Override
    public void build() {
        System.out.println("Construindo telhado...");
    }
}