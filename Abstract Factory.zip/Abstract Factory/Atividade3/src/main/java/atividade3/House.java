package atividade3;

/**
 *
 * @author mariana
 */
public interface House {
    
    public void build();
}
