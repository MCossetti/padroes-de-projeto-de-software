package atividade3;

/**
 *
 * @author mariana
 */
public class Walls implements House {

    @Override
    public void build() {
        System.out.println("Construindo parede...");
    }
}