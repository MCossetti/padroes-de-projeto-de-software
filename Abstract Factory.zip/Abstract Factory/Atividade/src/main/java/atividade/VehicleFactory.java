package atividade;

/**
 *
 * @author mariana
 */
public abstract class VehicleFactory {
    public abstract Vehicle produceCar();
    public abstract Vehicle produceMotorcycle();
    public abstract Vehicle produceTruck();
}
