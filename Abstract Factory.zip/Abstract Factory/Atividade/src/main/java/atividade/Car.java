package atividade;

/**
 *
 * @author mariana
 */
public class Car implements Vehicle {

    @Override
    public void manufacture() {
        System.out.println("Produzindo um carro.");
    }
}
