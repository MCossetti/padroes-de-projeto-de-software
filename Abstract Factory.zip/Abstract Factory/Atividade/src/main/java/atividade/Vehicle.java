package atividade;

/**
 *
 * @author mariana
 */
public interface Vehicle {
    public void manufacture();
}
