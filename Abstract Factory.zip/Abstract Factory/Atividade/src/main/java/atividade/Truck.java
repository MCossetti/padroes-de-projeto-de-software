package atividade;

/**
 *
 * @author mariana
 */
public class Truck implements Vehicle {

    @Override
    public void manufacture() {
        System.out.println("Produzindo um caminhão.");
    }
}
